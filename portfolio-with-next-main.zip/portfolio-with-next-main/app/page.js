import homeStyle from "./styles/home.module.css";

export default function Home() {
  return (
    <div className={homeStyle.home}>
      <h1>Welcome to my portfolio!</h1>
    </div>
  );
}
